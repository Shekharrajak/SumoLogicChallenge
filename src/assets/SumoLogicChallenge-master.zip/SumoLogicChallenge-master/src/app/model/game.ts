import { GamePlayResources } from "./GamePlayResources";

export class Game {
    title: string;
    game_play_resources: GamePlayResources;
}
