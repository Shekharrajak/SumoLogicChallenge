export class Installation {
    file_name: string;
    type: string;
}
